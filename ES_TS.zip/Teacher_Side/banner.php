

<div style="background-image: url('assets/img/bg.png'); background-repeat: no-repeat; background-size: cover; display:flex; justify-content:center; padding-top:2%; padding-bottom:2%;">
  <br>
  <img src="assets/img/GCU_logo.png" alt="" style="display: inline-block; vertical-align: middle;  width:10%; height:auto;">
  <div id="RBG" style="display: inline-block; vertical-align: middle;">
    <h5 style="font-family: 'Georgia', serif; color:black;">REPUBLIC OF THE PHILIPPINES</h5>
    <hr class="line" style="width: 100%; border-color: black; margin-bottom: 0;">
    <h1 style="font-family: 'Times New Roman', serif; color:black;"><span>BENGUET STATE UNIVERSITY</span></h1>
    <h1 style="font-family: 'Garamond', serif; font-weight: bold; color:black;">GUIDANCE AND COUNSELING UNIT</h1>
  </div>
</div>

<style>

#RBG h5{
  font-size: 1vw;
 }
 #RBG h3{
  font-size: 1.8vw;
 }
 #RBG h1{
  font-size: 2vw;
 }
 </style>