


    <!-- Welcome-message -->
<section class="welcome-message">
    <section style="background-color: #F5F5DC; color:black;">
    <div class="container">
        <div style=" display:flex; justify-content:center; padding-top:2%; padding-bottom: 2%;">
  <br>
  <img src="assets/images/GCU_logo.png" alt="" style="display: inline-block; vertical-align: middle;  width:10%; height:auto;">
  <div id="RBG" style="display: inline-block; vertical-align: middle;">
    <h5 style="font-family: 'Georgia', serif;">REPUBLIC OF THE PHILIPPINES</h5>
    <hr class="line" style="width: 100%; border-color: black; margin-bottom: 0;">
    <h1 style="font-family: 'Times New Roman', serif;"><span>BENGUET STATE UNIVERSITY</span></h1>
    <h1 style="font-family: 'Garamond', serif; font-weight: bold;">GUIDANCE AND COUNSELING UNIT</h1>
  </div>
</div>