<!DOCTYPE html>
<html lang="en">



<section id="topbar" class="topbar d-flex align-items-center" style="background-color: #008374; height: auto; color:white;">
    <br>
    <br>
    <br>
    <br>
    <footer class="d-flex justify-content-center" style="width: 100%;">
    
        <br>

        <p style="text-align: center; margin: 0; display: block;">BENGUET STATE UNIVERSITY <br> &copy; <?php echo date("Y"); ?>. Guidance and Counseling Unit. All rights reserved.</p>
        <br>
        
    </footer>
</section>

</html>
